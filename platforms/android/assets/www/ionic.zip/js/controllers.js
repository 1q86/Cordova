angular.module('app.controllers', [])
  
.controller('page2Ctrl', function($scope) {

})
   
.controller('page3Ctrl', function($scope) {

})
   
.controller('page4Ctrl', function($scope) {

})
         
.controller('loginCtrl', function($scope) {

})
   
.controller('signupCtrl', function($scope) {

})
   
.controller('userInfoCtrl', function($scope) {

})
   
.controller('aboutCtrl', function($scope) {

})
   
.controller('feedbackCtrl', function($scope) {

})
 